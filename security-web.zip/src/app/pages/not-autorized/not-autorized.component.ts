import { Component } from '@angular/core';

@Component({
  selector: 'app-not-autorized',
  templateUrl: './not-autorized.component.html',
  styleUrls: ['./not-autorized.component.css']
})
export class NotAutorizedComponent {

}
